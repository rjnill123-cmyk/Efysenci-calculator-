import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as RotateCcw, c as Moon, i as Save, l as MessageCircle, n as Trash2, o as Printer, r as Sun, s as Plus, u as Copy } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D4KgCIOg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function num(value) {
	const x = parseFloat(value);
	if (!Number.isFinite(x) || x < 0) return 0;
	return x;
}
/** Same rounding as the original sheet: no forced trailing zeros. */
function fmt(x, d = 1) {
	return (Math.round(x * 10 ** d) / 10 ** d).toString();
}
function todayISO() {
	const d = /* @__PURE__ */ new Date();
	const z = (n) => String(n).padStart(2, "0");
	return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
}
function dateBn(iso) {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return "";
	const [y, m, d] = iso.split("-");
	return `${d}/${m}/${y}`;
}
function newStyleId() {
	return `st-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}
function blankDraft(date = "") {
	return {
		date,
		line: "",
		manpower: "",
		hours: "",
		otPeople: "",
		otHours: "",
		styles: [{
			id: "style-1",
			name: "",
			qty: "",
			smv: ""
		}]
	};
}
function calculate(draft) {
	const styles = draft.styles.map((style, index) => {
		const qty = num(style.qty);
		const smv = num(style.smv);
		return {
			name: style.name.trim() || `স্টাইল ${index + 1}`,
			qty,
			smv,
			minutes: qty * smv
		};
	});
	const manpower = num(draft.manpower);
	const hours = num(draft.hours);
	const otPeople = num(draft.otPeople);
	const otHours = num(draft.otHours);
	const regularMinutes = manpower * hours * 60;
	const otMinutes = otPeople * otHours * 60;
	const availableMinutes = regularMinutes + otMinutes;
	const outputMinutes = styles.reduce((sum, style) => sum + style.minutes, 0);
	const pieces = styles.reduce((sum, style) => sum + style.qty, 0);
	const efficiency = availableMinutes > 0 ? outputMinutes / availableMinutes * 100 : 0;
	return {
		styles,
		pieces,
		outputMinutes,
		regularMinutes,
		otMinutes,
		availableMinutes,
		manHours: availableMinutes / 60,
		efficiency
	};
}
function bandOf(result) {
	if (result.availableMinutes <= 0) return "idle";
	if (result.efficiency >= 70) return "good";
	if (result.efficiency >= 50) return "mid";
	return "bad";
}
function bandLabel(band) {
	if (band === "good") return "ভালো";
	if (band === "mid") return "মাঝারি";
	if (band === "bad") return "কম";
	return "";
}
function buildReport(draft, result) {
	const manpower = num(draft.manpower);
	const hours = num(draft.hours);
	const otPeople = num(draft.otPeople);
	const otHours = num(draft.otHours);
	const date = dateBn(draft.date);
	const line = draft.line.trim();
	let report = "ফিনিশিং লাইন – দৈনিক ইফিসেন্সি রিপোর্ট\n";
	if (date) report += `তারিখ: ${date}\n`;
	if (line) report += `লাইন: ${line}\n`;
	report += "----------------\n";
	report += `ম্যান পাওয়ার: ${fmt(manpower, 2)} জন × ${fmt(hours, 2)} ঘণ্টা = ${fmt(result.regularMinutes / 60, 2)} ম্যান-আওয়ার\n`;
	if (otPeople > 0 && otHours > 0) report += `অতিরিক্ত: ${fmt(otPeople, 2)} জন × ${fmt(otHours, 2)} ঘণ্টা = ${fmt(result.otMinutes / 60, 2)} ম্যান-আওয়ার\n`;
	report += `মোট ম্যান-আওয়ার: ${fmt(result.manHours, 2)} (${fmt(result.availableMinutes, 0)} মিনিট)\n`;
	report += "----------------\nপ্রডাকশন:\n";
	result.styles.forEach((style, index) => {
		if (style.qty > 0 || style.smv > 0) report += `${index + 1}) ${style.name}: ${fmt(style.qty, 0)} পিস × SMV ${fmt(style.smv, 2)} = ${fmt(style.minutes, 1)} মিনিট\n`;
	});
	report += `মোট প্রডাকশন: ${fmt(result.pieces, 0)} পিস\nআউটপুট মিনিট: ${fmt(result.outputMinutes, 1)}\n`;
	report += "----------------\n";
	report += `টোটাল ইফিসেন্সি: ${fmt(result.efficiency, 2)}%\n`;
	report += "(সূত্র: আউটপুট মিনিট ÷ উপলব্ধ মিনিট × ১০০)";
	return report;
}
var DRAFT_KEY = "fl-draft-v1";
var SAVED_KEY = "fl-saved-v1";
function isStyle(value) {
	if (!value || typeof value !== "object") return false;
	const style = value;
	return typeof style.id === "string" && typeof style.name === "string" && typeof style.qty === "string" && typeof style.smv === "string";
}
function normalizeDraft(value) {
	if (!value || typeof value !== "object") return null;
	const raw = value;
	const styles = Array.isArray(raw.styles) ? raw.styles.filter(isStyle) : [];
	const base = blankDraft(typeof raw.date === "string" ? raw.date : "");
	return {
		...base,
		line: typeof raw.line === "string" ? raw.line : "",
		manpower: typeof raw.manpower === "string" ? raw.manpower : "",
		hours: typeof raw.hours === "string" ? raw.hours : "",
		otPeople: typeof raw.otPeople === "string" ? raw.otPeople : "",
		otHours: typeof raw.otHours === "string" ? raw.otHours : "",
		styles: styles.length > 0 ? styles : base.styles
	};
}
function loadDraft() {
	try {
		const raw = localStorage.getItem(DRAFT_KEY);
		if (!raw) return null;
		return normalizeDraft(JSON.parse(raw));
	} catch {
		return null;
	}
}
function saveDraft(draft) {
	localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
}
function loadSaved() {
	try {
		const raw = localStorage.getItem(SAVED_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [];
		return parsed.flatMap((item) => {
			if (!item || typeof item !== "object") return [];
			const row = item;
			const draft = normalizeDraft(row.draft);
			if (!draft || typeof row.id !== "string" || typeof row.savedAt !== "number") return [];
			return [{
				id: row.id,
				savedAt: row.savedAt,
				draft
			}];
		});
	} catch {
		return [];
	}
}
function saveSaved(rows) {
	localStorage.setItem(SAVED_KEY, JSON.stringify(rows.slice(0, 30)));
}
var fieldClass = "h-11 w-full rounded-xl border border-line bg-paper px-3 text-base text-ink outline-none placeholder:text-muted/70 focus-visible:border-primary focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary";
var btn = "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-base font-semibold transition-colors duration-150 disabled:cursor-not-allowed disabled:opacity-40";
function toneClass(band) {
	if (band === "good") return "text-good";
	if (band === "mid") return "text-mid";
	if (band === "bad") return "text-bad";
	return "text-ink";
}
function barClass(band) {
	if (band === "good") return "bg-good";
	if (band === "mid") return "bg-mid";
	if (band === "bad") return "bg-bad";
	return "bg-line";
}
function pillClass(band) {
	if (band === "good") return "bg-good-soft text-good";
	if (band === "mid") return "bg-mid-soft text-mid";
	if (band === "bad") return "bg-bad-soft text-bad";
	return "bg-primary-soft text-primary";
}
async function copyText(text) {
	try {
		await navigator.clipboard.writeText(text);
		return true;
	} catch {
		try {
			const area = document.createElement("textarea");
			area.value = text;
			area.setAttribute("readonly", "");
			area.style.position = "fixed";
			area.style.left = "-9999px";
			document.body.appendChild(area);
			area.select();
			const ok = document.execCommand("copy");
			area.remove();
			return ok;
		} catch {
			return false;
		}
	}
}
function clock(ts) {
	const d = new Date(ts);
	const z = (n) => String(n).padStart(2, "0");
	return `${z(d.getHours())}:${z(d.getMinutes())}`;
}
function Field({ id, label, value, onChange, placeholder, type = "text", inputMode }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor: id,
			className: "mb-1 block text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id,
			className: fieldClass,
			type,
			inputMode,
			value,
			placeholder,
			autoComplete: "off",
			spellCheck: false,
			onChange: (event) => onChange(event.target.value)
		})]
	});
}
function Section({ index, title, action, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-3 rounded-2xl border border-line bg-card p-4 shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "flex items-center gap-2 text-base font-semibold text-primary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "inline-flex h-7 min-w-7 items-center justify-center rounded-lg bg-primary-soft px-1.5 text-xs font-bold tabular-nums",
					children: index
				}), title]
			}), action]
		}), children]
	});
}
function Calculator() {
	const [draft, setDraft] = (0, import_react.useState)(() => blankDraft());
	const [saved, setSaved] = (0, import_react.useState)([]);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [theme, setTheme] = (0, import_react.useState)("pending");
	const [systemDark, setSystemDark] = (0, import_react.useState)(false);
	const [msg, setMsg] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const stored = loadDraft();
		setDraft(stored ?? blankDraft(todayISO()));
		setSaved(loadSaved());
		const storedTheme = localStorage.getItem("fl-theme");
		setTheme(storedTheme === "light" || storedTheme === "dark" ? storedTheme : "system");
		const media = window.matchMedia("(prefers-color-scheme: dark)");
		setSystemDark(media.matches);
		const onChange = () => setSystemDark(media.matches);
		media.addEventListener("change", onChange);
		setHydrated(true);
		return () => media.removeEventListener("change", onChange);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		saveDraft(draft);
	}, [draft, hydrated]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		saveSaved(saved);
	}, [saved, hydrated]);
	(0, import_react.useEffect)(() => {
		if (theme === "pending") return;
		const root = document.documentElement;
		if (theme === "system") root.removeAttribute("data-theme");
		else root.setAttribute("data-theme", theme);
		localStorage.setItem("fl-theme", theme);
	}, [theme]);
	(0, import_react.useEffect)(() => {
		if (!confirm) return;
		const previous = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			document.body.style.overflow = previous;
		};
	}, [confirm]);
	const result = (0, import_react.useMemo)(() => calculate(draft), [draft]);
	const report = (0, import_react.useMemo)(() => buildReport(draft, result), [draft, result]);
	const band = bandOf(result);
	const isDark = theme === "dark" || theme !== "light" && systemDark;
	const otPeople = num(draft.otPeople);
	const otHours = num(draft.otHours);
	const otPartial = otPeople > 0 !== otHours > 0;
	function patch(partial) {
		setDraft((current) => ({
			...current,
			...partial
		}));
	}
	function patchStyle(id, partial) {
		setDraft((current) => ({
			...current,
			styles: current.styles.map((style) => style.id === id ? {
				...style,
				...partial
			} : style)
		}));
	}
	function addStyle() {
		setDraft((current) => {
			if (current.styles.length >= 15) return current;
			return {
				...current,
				styles: [...current.styles, {
					id: newStyleId(),
					name: "",
					qty: "",
					smv: ""
				}]
			};
		});
	}
	function removeStyle(id) {
		setDraft((current) => {
			if (current.styles.length <= 1) return current;
			return {
				...current,
				styles: current.styles.filter((style) => style.id !== id)
			};
		});
	}
	function loadExample() {
		setDraft({
			...blankDraft(draft.date || todayISO()),
			line: "লাইন-১",
			manpower: "22",
			hours: "8",
			styles: [{
				id: newStyleId(),
				name: "পোলো",
				qty: "600",
				smv: "8"
			}, {
				id: newStyleId(),
				name: "টি-শার্ট",
				qty: "480",
				smv: "6.5"
			}]
		});
		setMsg("উদাহরণ বসানো হয়েছে — ২২ জন × ৮ ঘণ্টা, ইফিসেন্সি ৭৫%।");
	}
	async function onCopy() {
		const ok = await copyText(report);
		setMsg(ok ? "রিপোর্ট কপি হয়েছে। এখন SMS বা WhatsApp-এ পেস্ট করুন।" : "কপি হয়নি। রিপোর্টের লেখা চেপে ধরে সিলেক্ট করে কপি করুন।");
	}
	function onWhatsApp() {
		const url = `https://wa.me/?text=${encodeURIComponent(report)}`;
		window.open(url, "_blank", "noopener,noreferrer");
	}
	function onSave() {
		if (result.pieces === 0 && num(draft.manpower) === 0) {
			setMsg("প্রডাকশন বা ম্যান পাওয়ার দিয়ে তারপর রাখুন।");
			return;
		}
		const snapshot = JSON.parse(JSON.stringify(draft));
		const row = {
			id: `r-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
			savedAt: Date.now(),
			draft: snapshot
		};
		setSaved((rows) => [row, ...rows].slice(0, 30));
		setMsg("রিপোর্ট এই ফোনে রাখা হয়েছে।");
	}
	function applyConfirm() {
		if (!confirm) return;
		if (confirm.kind === "reset") {
			setDraft(blankDraft(todayISO()));
			setMsg("নতুন শিট খোলা হয়েছে। রাখা রিপোর্ট আগের মতো আছে।");
		} else {
			setSaved((rows) => rows.filter((row) => row.id !== confirm.id));
			setMsg("রাখা রিপোর্ট মুছে ফেলা হয়েছে।");
		}
		setConfirm(null);
	}
	const meter = Math.max(0, Math.min(100, result.efficiency));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 bg-primary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-2xl px-4 pb-32 pt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "mb-5 flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-primary",
								children: "গার্মেন্টস ফিনিশিং"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl font-bold leading-snug text-balance",
								children: "দৈনিক ইফিসেন্সি"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-pretty text-muted",
								children: "তথ্য দিলেই হিসাব নিজে নিজে হবে"
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-11 shrink-0 items-center justify-center rounded-xl border border-line bg-card text-ink",
							"aria-label": isDark ? "লাইট থিম" : "ডার্ক থিম",
							onClick: () => setTheme(isDark ? "light" : "dark"),
							children: isDark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-5" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						index: "০১",
						title: "লাইনের তথ্য",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-sm font-semibold text-primary",
							onClick: loadExample,
							children: "উদাহরণ"
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									id: "date",
									label: "তারিখ",
									type: "date",
									value: draft.date,
									onChange: (date) => patch({ date })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									id: "line",
									label: "লাইন / লেন নম্বর",
									placeholder: "যেমন: লাইন-১",
									value: draft.line,
									onChange: (line) => patch({ line })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									id: "mp",
									label: "আজকের ম্যান পাওয়ার (জন)",
									inputMode: "decimal",
									placeholder: "0",
									value: draft.manpower,
									onChange: (manpower) => patch({ manpower })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									id: "hrs",
									label: "কাজের ঘণ্টা",
									inputMode: "decimal",
									placeholder: "8",
									value: draft.hours,
									onChange: (hours) => patch({ hours })
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						index: "০২",
						title: "আজকের প্রডাকশন",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-col gap-3",
							children: draft.styles.map((style, index) => {
								const calc = result.styles[index];
								const active = calc.qty > 0 || calc.smv > 0;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-dashed border-line p-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mb-2 flex items-center justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-sm font-medium text-muted",
												children: ["স্টাইল ", index + 1]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												className: "inline-flex min-h-11 items-center gap-1 rounded-lg px-2 text-sm font-semibold text-bad disabled:opacity-40",
												onClick: () => removeStyle(style.id),
												disabled: draft.styles.length <= 1,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "মুছুন"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-2 gap-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "col-span-2",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
														id: `${style.id}-name`,
														label: "স্টাইল / অর্ডার",
														placeholder: "নাম",
														value: style.name,
														onChange: (name) => patchStyle(style.id, { name })
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
													id: `${style.id}-qty`,
													label: "পরিমাণ (পিস)",
													inputMode: "decimal",
													placeholder: "0",
													value: style.qty,
													onChange: (qty) => patchStyle(style.id, { qty })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
													id: `${style.id}-smv`,
													label: "SMV",
													inputMode: "decimal",
													placeholder: "0.00",
													value: style.smv,
													onChange: (smv) => patchStyle(style.id, { smv })
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm tabular-nums text-muted",
											children: active ? `${fmt(calc.qty, 0)} পিস × SMV ${fmt(calc.smv, 2)} = ${fmt(calc.minutes, 1)} মিনিট` : "পরিমাণ ও SMV দিলে মিনিট বের হবে"
										})
									]
								}, style.id);
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							id: "addStyle",
							className: `${btn} mt-3 w-full border border-primary bg-transparent text-primary`,
							onClick: addStyle,
							disabled: draft.styles.length >= 15,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "আরেকটি স্টাইল যোগ করুন"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						index: "০৩",
						title: "অতিরিক্ত (ওভারটাইম) কাজ",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									id: "otp",
									label: "অতিরিক্ত কতজন",
									inputMode: "decimal",
									placeholder: "0",
									value: draft.otPeople,
									onChange: (otPeople) => patch({ otPeople })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									id: "oth",
									label: "কত ঘণ্টা করে",
									inputMode: "decimal",
									placeholder: "0",
									value: draft.otHours,
									onChange: (otHours) => patch({ otHours })
								})]
							}),
							otPartial ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-mid",
								children: "জনসংখ্যা ও ঘণ্টা দুটোই দিলে অতিরিক্ত সময় গোনা হবে।"
							}) : null,
							otPeople > 0 && otHours > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm tabular-nums text-muted",
								children: [
									"অতিরিক্ত ",
									fmt(result.otMinutes, 0),
									" মিনিট যোগ হয়েছে।"
								]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						index: "০৪",
						title: "হিসাবের খুঁটিনাটি",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-1 flex items-baseline justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: `text-3xl font-bold leading-none tabular-nums ${toneClass(band)}`,
											children: [fmt(result.efficiency, 2), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-lg",
												children: "%"
											})]
										}), band !== "idle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded-full px-2.5 py-1 text-sm font-semibold ${pillClass(band)}`,
											children: bandLabel(band)
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm text-muted",
											children: "ম্যান পাওয়ার ও ঘণ্টা দিন"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-2 overflow-hidden rounded-full bg-line",
										"aria-hidden": "true",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `h-full rounded-full ${barClass(band)}`,
											style: { width: `${meter}%` }
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs text-muted",
										children: "৭০% বা বেশি ভালো · ৫০–৬৯% মাঝারি · তার নিচে কম"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "মোট প্রডাকশন",
										value: `${fmt(result.pieces, 0)} পিস`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "আউটপুট মিনিট (SAM)",
										value: fmt(result.outputMinutes, 1)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "মোট ম্যান-আওয়ার",
										value: `${fmt(result.manHours, 2)} ঘণ্টা`,
										hint: result.otMinutes > 0 ? `নিয়মিত ${fmt(result.regularMinutes / 60, 2)} + অতিরিক্ত ${fmt(result.otMinutes / 60, 2)}` : void 0
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "উপলব্ধ মিনিট",
										value: fmt(result.availableMinutes, 0)
									})
								]
							}),
							result.pieces > 0 && result.outputMinutes === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-mid",
								children: "SMV না দিলে ইফিসেন্সি ০% থাকবে।"
							}) : null,
							result.efficiency > 100 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-mid",
								children: "১০০% এর বেশি — SMV বা প্রডাকশন যাচাই করুন।"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs text-pretty text-muted",
								children: "সূত্র: আউটপুট মিনিট ÷ উপলব্ধ মিনিট × ১০০। উপলব্ধ মিনিট = (জন × ঘণ্টা + অতিরিক্ত জন × ঘণ্টা) × ৬০।"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						index: "০৫",
						title: "রিপোর্ট",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								id: "print-root",
								className: "mb-3 overflow-x-auto whitespace-pre-wrap break-words rounded-xl border border-line bg-paper p-3 text-sm leading-relaxed text-ink",
								children: report
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										id: "copy",
										className: `${btn} col-span-2 bg-primary text-on-primary`,
										onClick: onCopy,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), "কপি করুন (SMS)"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: `${btn} border border-primary bg-transparent text-primary`,
										onClick: onWhatsApp,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), "WhatsApp"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										id: "print",
										className: `${btn} border border-primary bg-transparent text-primary`,
										onClick: () => window.print(),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "প্রিন্ট"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										id: "save",
										className: `${btn} border border-line bg-card text-ink`,
										onClick: onSave,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), "রাখুন"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										id: "reset",
										className: `${btn} border border-bad bg-transparent text-bad`,
										onClick: () => setConfirm({ kind: "reset" }),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "নতুন শিট"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								id: "msg",
								role: "status",
								className: "mt-2 min-h-5 text-sm text-pretty text-muted",
								children: msg
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						index: "০৬",
						title: "রাখা রিপোর্ট",
						children: [saved.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-pretty text-muted",
							children: "এখনো কিছু রাখা হয়নি। হিসাব শেষে «রাখুন» চাপলে এই ফোনে থেকে যাবে।"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "flex flex-col gap-2",
							children: saved.map((row) => {
								const rowResult = calculate(row.draft);
								const rowBand = bandOf(rowResult);
								const when = dateBn(row.draft.date) || "তারিখ নেই";
								const line = row.draft.line.trim();
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2 rounded-xl bg-paper px-3 py-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "min-w-0 flex-1 text-left",
											onClick: () => {
												setDraft(JSON.parse(JSON.stringify(row.draft)));
												setMsg("রাখা রিপোর্ট খোলা হয়েছে।");
												window.scrollTo(0, 0);
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "block truncate text-sm font-semibold text-ink",
												children: [
													when,
													line ? ` · ${line}` : "",
													" · ",
													clock(row.savedAt)
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "block text-sm tabular-nums text-muted",
												children: [fmt(rowResult.pieces, 0), " পিস"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `shrink-0 text-base font-bold tabular-nums ${toneClass(rowBand)}`,
											children: [fmt(rowResult.efficiency, 2), "%"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "inline-flex size-11 shrink-0 items-center justify-center rounded-lg text-bad",
											"aria-label": "রাখা রিপোর্ট মুছুন",
											onClick: () => setConfirm({
												kind: "delete",
												id: row.id
											}),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
										})
									]
								}, row.id);
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs text-pretty text-muted",
							children: "হিসাব এই ফোনেই সেভ হয়, কোথাও আপলোড হয় না।"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "no-print fixed inset-x-0 bottom-0 z-20 border-t border-line bg-card/95 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "safe-bottom mx-auto flex max-w-2xl items-center justify-between gap-3 px-4 pt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-xs text-muted",
							children: draft.line.trim() || "টোটাল ইফিসেন্সি"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							id: "eff",
							className: `text-4xl font-bold leading-none tabular-nums ${toneClass(band)}`,
							children: [fmt(result.efficiency, 2), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xl",
								children: "%"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "shrink-0 text-right",
						children: [band !== "idle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `inline-flex rounded-full px-2.5 py-1 text-sm font-semibold ${pillClass(band)}`,
							children: bandLabel(band)
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: "ঘণ্টা ও জনবল দিন"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm font-semibold tabular-nums text-ink",
							children: [fmt(result.pieces, 0), " পিস"]
						})]
					})]
				})
			}),
			confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-30 flex items-end justify-center bg-ink/40 p-4 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "confirm-title",
					className: "w-full max-w-sm rounded-2xl border border-line bg-card p-5 shadow-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "confirm-title",
							className: "text-lg font-bold text-ink",
							children: confirm.kind === "reset" ? "নতুন করে শুরু করবেন?" : "এই রিপোর্ট মুছবেন?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-pretty text-muted",
							children: confirm.kind === "reset" ? "আজকের ঘর খালি হয়ে যাবে। আগে রাখা রিপোর্ট থাকবে।" : "এই রাখা রিপোর্ট আর ফিরে পাওয়া যাবে না।"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `${btn} border border-line bg-card text-ink`,
								onClick: () => setConfirm(null),
								children: "না"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `${btn} bg-bad text-on-primary`,
								onClick: applyConfirm,
								children: "হ্যাঁ, মুছুন"
							})]
						})
					]
				})
			}) : null
		]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-paper px-3 py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-lg font-semibold tabular-nums text-ink",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tabular-nums text-muted",
				children: hint
			}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, {});
}
//#endregion
export { Home as component };
