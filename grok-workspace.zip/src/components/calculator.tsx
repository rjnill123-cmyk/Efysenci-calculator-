import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  Copy,
  MessageCircle,
  Moon,
  Plus,
  Printer,
  RotateCcw,
  Save,
  Sun,
  Trash2,
} from "lucide-react";
import {
  bandLabel,
  bandOf,
  blankDraft,
  buildReport,
  calculate,
  dateBn,
  fmt,
  newStyleId,
  num,
  todayISO,
  type Band,
  type Draft,
  type StyleInput,
} from "@/lib/efficiency";
import { loadDraft, loadSaved, saveDraft, saveSaved, type SavedReport } from "@/lib/storage";

type Confirm = { kind: "reset" } | { kind: "delete"; id: string } | null;
type ThemeMode = "light" | "dark" | "system" | "pending";

const fieldClass =
  "h-11 w-full rounded-xl border border-line bg-paper px-3 text-base text-ink outline-none placeholder:text-muted/70 focus-visible:border-primary focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary";

const btn =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-base font-semibold transition-colors duration-150 disabled:cursor-not-allowed disabled:opacity-40";

function toneClass(band: Band): string {
  if (band === "good") return "text-good";
  if (band === "mid") return "text-mid";
  if (band === "bad") return "text-bad";
  return "text-ink";
}

function barClass(band: Band): string {
  if (band === "good") return "bg-good";
  if (band === "mid") return "bg-mid";
  if (band === "bad") return "bg-bad";
  return "bg-line";
}

function pillClass(band: Band): string {
  if (band === "good") return "bg-good-soft text-good";
  if (band === "mid") return "bg-mid-soft text-mid";
  if (band === "bad") return "bg-bad-soft text-bad";
  return "bg-primary-soft text-primary";
}

async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const area = document.createElement("textarea");
      area.value = text;
      area.setAttribute("readonly", "");
      area.style.position = "fixed";
      area.style.left = "-9999px";
      document.body.appendChild(area);
      area.select();
      const ok = document.execCommand("copy");
      area.remove();
      return ok;
    } catch {
      return false;
    }
  }
}

function clock(ts: number): string {
  const d = new Date(ts);
  const z = (n: number) => String(n).padStart(2, "0");
  return `${z(d.getHours())}:${z(d.getMinutes())}`;
}

function Field({
  id,
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  inputMode,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
  inputMode?: "decimal" | "text";
}) {
  return (
    <div className="min-w-0">
      <label htmlFor={id} className="mb-1 block text-sm text-muted">
        {label}
      </label>
      <input
        id={id}
        className={fieldClass}
        type={type}
        inputMode={inputMode}
        value={value}
        placeholder={placeholder}
        autoComplete="off"
        spellCheck={false}
        onChange={(event) => onChange(event.target.value)}
      />
    </div>
  );
}

function Section({
  index,
  title,
  action,
  children,
}: {
  index: string;
  title: string;
  action?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="mb-3 rounded-2xl border border-line bg-card p-4 shadow-sm">
      <div className="mb-3 flex items-center justify-between gap-3">
        <h2 className="flex items-center gap-2 text-base font-semibold text-primary">
          <span className="inline-flex h-7 min-w-7 items-center justify-center rounded-lg bg-primary-soft px-1.5 text-xs font-bold tabular-nums">
            {index}
          </span>
          {title}
        </h2>
        {action}
      </div>
      {children}
    </section>
  );
}

export function Calculator() {
  const [draft, setDraft] = useState<Draft>(() => blankDraft());
  const [saved, setSaved] = useState<SavedReport[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [theme, setTheme] = useState<ThemeMode>("pending");
  const [systemDark, setSystemDark] = useState(false);
  const [msg, setMsg] = useState("");
  const [confirm, setConfirm] = useState<Confirm>(null);

  useEffect(() => {
    const stored = loadDraft();
    setDraft(stored ?? blankDraft(todayISO()));
    setSaved(loadSaved());
    const storedTheme = localStorage.getItem("fl-theme");
    setTheme(storedTheme === "light" || storedTheme === "dark" ? storedTheme : "system");
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    setSystemDark(media.matches);
    const onChange = () => setSystemDark(media.matches);
    media.addEventListener("change", onChange);
    setHydrated(true);
    return () => media.removeEventListener("change", onChange);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    saveDraft(draft);
  }, [draft, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    saveSaved(saved);
  }, [saved, hydrated]);

  useEffect(() => {
    if (theme === "pending") return;
    const root = document.documentElement;
    if (theme === "system") root.removeAttribute("data-theme");
    else root.setAttribute("data-theme", theme);
    localStorage.setItem("fl-theme", theme);
  }, [theme]);

  useEffect(() => {
    if (!confirm) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [confirm]);

  const result = useMemo(() => calculate(draft), [draft]);
  const report = useMemo(() => buildReport(draft, result), [draft, result]);
  const band = bandOf(result);
  const isDark = theme === "dark" || (theme !== "light" && systemDark);
  const otPeople = num(draft.otPeople);
  const otHours = num(draft.otHours);
  const otPartial = (otPeople > 0) !== (otHours > 0);

  function patch(partial: Partial<Draft>) {
    setDraft((current) => ({ ...current, ...partial }));
  }

  function patchStyle(id: string, partial: Partial<StyleInput>) {
    setDraft((current) => ({
      ...current,
      styles: current.styles.map((style) => (style.id === id ? { ...style, ...partial } : style)),
    }));
  }

  function addStyle() {
    setDraft((current) => {
      if (current.styles.length >= 15) return current;
      return {
        ...current,
        styles: [...current.styles, { id: newStyleId(), name: "", qty: "", smv: "" }],
      };
    });
  }

  function removeStyle(id: string) {
    setDraft((current) => {
      if (current.styles.length <= 1) return current;
      return { ...current, styles: current.styles.filter((style) => style.id !== id) };
    });
  }

  function loadExample() {
    setDraft({
      ...blankDraft(draft.date || todayISO()),
      line: "লাইন-১",
      manpower: "22",
      hours: "8",
      styles: [
        { id: newStyleId(), name: "পোলো", qty: "600", smv: "8" },
        { id: newStyleId(), name: "টি-শার্ট", qty: "480", smv: "6.5" },
      ],
    });
    setMsg("উদাহরণ বসানো হয়েছে — ২২ জন × ৮ ঘণ্টা, ইফিসেন্সি ৭৫%।");
  }

  async function onCopy() {
    const ok = await copyText(report);
    setMsg(
      ok
        ? "রিপোর্ট কপি হয়েছে। এখন SMS বা WhatsApp-এ পেস্ট করুন।"
        : "কপি হয়নি। রিপোর্টের লেখা চেপে ধরে সিলেক্ট করে কপি করুন।",
    );
  }

  function onWhatsApp() {
    const url = `https://wa.me/?text=${encodeURIComponent(report)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  }

  function onSave() {
    if (result.pieces === 0 && num(draft.manpower) === 0) {
      setMsg("প্রডাকশন বা ম্যান পাওয়ার দিয়ে তারপর রাখুন।");
      return;
    }
    const snapshot = JSON.parse(JSON.stringify(draft)) as Draft;
    const row: SavedReport = {
      id: `r-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
      savedAt: Date.now(),
      draft: snapshot,
    };
    setSaved((rows) => [row, ...rows].slice(0, 30));
    setMsg("রিপোর্ট এই ফোনে রাখা হয়েছে।");
  }

  function applyConfirm() {
    if (!confirm) return;
    if (confirm.kind === "reset") {
      setDraft(blankDraft(todayISO()));
      setMsg("নতুন শিট খোলা হয়েছে। রাখা রিপোর্ট আগের মতো আছে।");
    } else {
      setSaved((rows) => rows.filter((row) => row.id !== confirm.id));
      setMsg("রাখা রিপোর্ট মুছে ফেলা হয়েছে।");
    }
    setConfirm(null);
  }

  const meter = Math.max(0, Math.min(100, result.efficiency));

  return (
    <div className="min-h-dvh bg-paper text-ink">
      <div className="h-1 bg-primary" />
      <div className="mx-auto w-full max-w-2xl px-4 pb-32 pt-5">
        <header className="mb-5 flex items-start justify-between gap-3">
          <div>
            <p className="text-sm font-medium text-primary">গার্মেন্টস ফিনিশিং</p>
            <h1 className="text-2xl font-bold leading-snug text-balance">দৈনিক ইফিসেন্সি</h1>
            <p className="mt-1 text-sm text-pretty text-muted">তথ্য দিলেই হিসাব নিজে নিজে হবে</p>
          </div>
          <button
            type="button"
            className="inline-flex size-11 shrink-0 items-center justify-center rounded-xl border border-line bg-card text-ink"
            aria-label={isDark ? "লাইট থিম" : "ডার্ক থিম"}
            onClick={() => setTheme(isDark ? "light" : "dark")}
          >
            {isDark ? <Sun className="size-5" /> : <Moon className="size-5" />}
          </button>
        </header>

        <Section
          index="০১"
          title="লাইনের তথ্য"
          action={
            <button type="button" className="text-sm font-semibold text-primary" onClick={loadExample}>
              উদাহরণ
            </button>
          }
        >
          <div className="grid grid-cols-2 gap-3">
            <Field
              id="date"
              label="তারিখ"
              type="date"
              value={draft.date}
              onChange={(date) => patch({ date })}
            />
            <Field
              id="line"
              label="লাইন / লেন নম্বর"
              placeholder="যেমন: লাইন-১"
              value={draft.line}
              onChange={(line) => patch({ line })}
            />
            <Field
              id="mp"
              label="আজকের ম্যান পাওয়ার (জন)"
              inputMode="decimal"
              placeholder="0"
              value={draft.manpower}
              onChange={(manpower) => patch({ manpower })}
            />
            <Field
              id="hrs"
              label="কাজের ঘণ্টা"
              inputMode="decimal"
              placeholder="8"
              value={draft.hours}
              onChange={(hours) => patch({ hours })}
            />
          </div>
        </Section>

        <Section index="০২" title="আজকের প্রডাকশন">
          <div className="flex flex-col gap-3">
            {draft.styles.map((style, index) => {
              const calc = result.styles[index];
              const active = calc.qty > 0 || calc.smv > 0;
              return (
                <div key={style.id} className="rounded-xl border border-dashed border-line p-3">
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <p className="text-sm font-medium text-muted">স্টাইল {index + 1}</p>
                    <button
                      type="button"
                      className="inline-flex min-h-11 items-center gap-1 rounded-lg px-2 text-sm font-semibold text-bad disabled:opacity-40"
                      onClick={() => removeStyle(style.id)}
                      disabled={draft.styles.length <= 1}
                    >
                      <Trash2 className="size-4" />
                      মুছুন
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="col-span-2">
                      <Field
                        id={`${style.id}-name`}
                        label="স্টাইল / অর্ডার"
                        placeholder="নাম"
                        value={style.name}
                        onChange={(name) => patchStyle(style.id, { name })}
                      />
                    </div>
                    <Field
                      id={`${style.id}-qty`}
                      label="পরিমাণ (পিস)"
                      inputMode="decimal"
                      placeholder="0"
                      value={style.qty}
                      onChange={(qty) => patchStyle(style.id, { qty })}
                    />
                    <Field
                      id={`${style.id}-smv`}
                      label="SMV"
                      inputMode="decimal"
                      placeholder="0.00"
                      value={style.smv}
                      onChange={(smv) => patchStyle(style.id, { smv })}
                    />
                  </div>
                  <p className="mt-2 text-sm tabular-nums text-muted">
                    {active
                      ? `${fmt(calc.qty, 0)} পিস × SMV ${fmt(calc.smv, 2)} = ${fmt(calc.minutes, 1)} মিনিট`
                      : "পরিমাণ ও SMV দিলে মিনিট বের হবে"}
                  </p>
                </div>
              );
            })}
          </div>
          <button
            type="button"
            id="addStyle"
            className={`${btn} mt-3 w-full border border-primary bg-transparent text-primary`}
            onClick={addStyle}
            disabled={draft.styles.length >= 15}
          >
            <Plus className="size-4" />
            আরেকটি স্টাইল যোগ করুন
          </button>
        </Section>

        <Section index="০৩" title="অতিরিক্ত (ওভারটাইম) কাজ">
          <div className="grid grid-cols-2 gap-3">
            <Field
              id="otp"
              label="অতিরিক্ত কতজন"
              inputMode="decimal"
              placeholder="0"
              value={draft.otPeople}
              onChange={(otPeople) => patch({ otPeople })}
            />
            <Field
              id="oth"
              label="কত ঘণ্টা করে"
              inputMode="decimal"
              placeholder="0"
              value={draft.otHours}
              onChange={(otHours) => patch({ otHours })}
            />
          </div>
          {otPartial ? (
            <p className="mt-2 text-sm text-mid">জনসংখ্যা ও ঘণ্টা দুটোই দিলে অতিরিক্ত সময় গোনা হবে।</p>
          ) : null}
          {otPeople > 0 && otHours > 0 ? (
            <p className="mt-2 text-sm tabular-nums text-muted">
              অতিরিক্ত {fmt(result.otMinutes, 0)} মিনিট যোগ হয়েছে।
            </p>
          ) : null}
        </Section>

        <Section index="০৪" title="হিসাবের খুঁটিনাটি">
          <div className="mb-3">
            <div className="mb-1 flex items-baseline justify-between gap-3">
              <p className={`text-3xl font-bold leading-none tabular-nums ${toneClass(band)}`}>
                {fmt(result.efficiency, 2)}
                <span className="text-lg">%</span>
              </p>
              {band !== "idle" ? (
                <span className={`rounded-full px-2.5 py-1 text-sm font-semibold ${pillClass(band)}`}>
                  {bandLabel(band)}
                </span>
              ) : (
                <span className="text-sm text-muted">ম্যান পাওয়ার ও ঘণ্টা দিন</span>
              )}
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-line" aria-hidden="true">
              <div className={`h-full rounded-full ${barClass(band)}`} style={{ width: `${meter}%` }} />
            </div>
            <p className="mt-2 text-xs text-muted">৭০% বা বেশি ভালো · ৫০–৬৯% মাঝারি · তার নিচে কম</p>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Stat label="মোট প্রডাকশন" value={`${fmt(result.pieces, 0)} পিস`} />
            <Stat label="আউটপুট মিনিট (SAM)" value={fmt(result.outputMinutes, 1)} />
            <Stat
              label="মোট ম্যান-আওয়ার"
              value={`${fmt(result.manHours, 2)} ঘণ্টা`}
              hint={
                result.otMinutes > 0
                  ? `নিয়মিত ${fmt(result.regularMinutes / 60, 2)} + অতিরিক্ত ${fmt(result.otMinutes / 60, 2)}`
                  : undefined
              }
            />
            <Stat label="উপলব্ধ মিনিট" value={fmt(result.availableMinutes, 0)} />
          </div>
          {result.pieces > 0 && result.outputMinutes === 0 ? (
            <p className="mt-2 text-sm text-mid">SMV না দিলে ইফিসেন্সি ০% থাকবে।</p>
          ) : null}
          {result.efficiency > 100 ? (
            <p className="mt-2 text-sm text-mid">১০০% এর বেশি — SMV বা প্রডাকশন যাচাই করুন।</p>
          ) : null}
          <p className="mt-3 text-xs text-pretty text-muted">
            সূত্র: আউটপুট মিনিট ÷ উপলব্ধ মিনিট × ১০০। উপলব্ধ মিনিট = (জন × ঘণ্টা + অতিরিক্ত জন × ঘণ্টা) × ৬০।
          </p>
        </Section>

        <Section index="০৫" title="রিপোর্ট">
          <pre
            id="print-root"
            className="mb-3 overflow-x-auto whitespace-pre-wrap break-words rounded-xl border border-line bg-paper p-3 text-sm leading-relaxed text-ink"
          >
            {report}
          </pre>
          <div className="grid grid-cols-2 gap-2">
            <button type="button" id="copy" className={`${btn} col-span-2 bg-primary text-on-primary`} onClick={onCopy}>
              <Copy className="size-4" />
              কপি করুন (SMS)
            </button>
            <button
              type="button"
              className={`${btn} border border-primary bg-transparent text-primary`}
              onClick={onWhatsApp}
            >
              <MessageCircle className="size-4" />
              WhatsApp
            </button>
            <button
              type="button"
              id="print"
              className={`${btn} border border-primary bg-transparent text-primary`}
              onClick={() => window.print()}
            >
              <Printer className="size-4" />
              প্রিন্ট
            </button>
            <button type="button" id="save" className={`${btn} border border-line bg-card text-ink`} onClick={onSave}>
              <Save className="size-4" />
              রাখুন
            </button>
            <button
              type="button"
              id="reset"
              className={`${btn} border border-bad bg-transparent text-bad`}
              onClick={() => setConfirm({ kind: "reset" })}
            >
              <RotateCcw className="size-4" />
              নতুন শিট
            </button>
          </div>
          <p id="msg" role="status" className="mt-2 min-h-5 text-sm text-pretty text-muted">
            {msg}
          </p>
        </Section>

        <Section index="০৬" title="রাখা রিপোর্ট">
          {saved.length === 0 ? (
            <p className="text-sm text-pretty text-muted">
              এখনো কিছু রাখা হয়নি। হিসাব শেষে «রাখুন» চাপলে এই ফোনে থেকে যাবে।
            </p>
          ) : (
            <ul className="flex flex-col gap-2">
              {saved.map((row) => {
                const rowResult = calculate(row.draft);
                const rowBand = bandOf(rowResult);
                const when = dateBn(row.draft.date) || "তারিখ নেই";
                const line = row.draft.line.trim();
                return (
                  <li key={row.id} className="flex items-center gap-2 rounded-xl bg-paper px-3 py-2">
                    <button
                      type="button"
                      className="min-w-0 flex-1 text-left"
                      onClick={() => {
                        setDraft(JSON.parse(JSON.stringify(row.draft)) as Draft);
                        setMsg("রাখা রিপোর্ট খোলা হয়েছে।");
                        window.scrollTo(0, 0);
                      }}
                    >
                      <span className="block truncate text-sm font-semibold text-ink">
                        {when}
                        {line ? ` · ${line}` : ""} · {clock(row.savedAt)}
                      </span>
                      <span className="block text-sm tabular-nums text-muted">
                        {fmt(rowResult.pieces, 0)} পিস
                      </span>
                    </button>
                    <span className={`shrink-0 text-base font-bold tabular-nums ${toneClass(rowBand)}`}>
                      {fmt(rowResult.efficiency, 2)}%
                    </span>
                    <button
                      type="button"
                      className="inline-flex size-11 shrink-0 items-center justify-center rounded-lg text-bad"
                      aria-label="রাখা রিপোর্ট মুছুন"
                      onClick={() => setConfirm({ kind: "delete", id: row.id })}
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
          <p className="mt-3 text-xs text-pretty text-muted">
            হিসাব এই ফোনেই সেভ হয়, কোথাও আপলোড হয় না।
          </p>
        </Section>
      </div>

      <div className="no-print fixed inset-x-0 bottom-0 z-20 border-t border-line bg-card/95 backdrop-blur-sm">
        <div className="safe-bottom mx-auto flex max-w-2xl items-center justify-between gap-3 px-4 pt-3">
          <div className="min-w-0">
            <p className="truncate text-xs text-muted">{draft.line.trim() || "টোটাল ইফিসেন্সি"}</p>
            <p id="eff" className={`text-4xl font-bold leading-none tabular-nums ${toneClass(band)}`}>
              {fmt(result.efficiency, 2)}
              <span className="text-xl">%</span>
            </p>
          </div>
          <div className="shrink-0 text-right">
            {band !== "idle" ? (
              <span className={`inline-flex rounded-full px-2.5 py-1 text-sm font-semibold ${pillClass(band)}`}>
                {bandLabel(band)}
              </span>
            ) : (
              <span className="text-xs text-muted">ঘণ্টা ও জনবল দিন</span>
            )}
            <p className="mt-1 text-sm font-semibold tabular-nums text-ink">{fmt(result.pieces, 0)} পিস</p>
          </div>
        </div>
      </div>

      {confirm ? (
        <div className="fixed inset-0 z-30 flex items-end justify-center bg-ink/40 p-4 sm:items-center">
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="confirm-title"
            className="w-full max-w-sm rounded-2xl border border-line bg-card p-5 shadow-sm"
          >
            <h2 id="confirm-title" className="text-lg font-bold text-ink">
              {confirm.kind === "reset" ? "নতুন করে শুরু করবেন?" : "এই রিপোর্ট মুছবেন?"}
            </h2>
            <p className="mt-1 text-sm text-pretty text-muted">
              {confirm.kind === "reset"
                ? "আজকের ঘর খালি হয়ে যাবে। আগে রাখা রিপোর্ট থাকবে।"
                : "এই রাখা রিপোর্ট আর ফিরে পাওয়া যাবে না।"}
            </p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <button
                type="button"
                className={`${btn} border border-line bg-card text-ink`}
                onClick={() => setConfirm(null)}
              >
                না
              </button>
              <button type="button" className={`${btn} bg-bad text-on-primary`} onClick={applyConfirm}>
                হ্যাঁ, মুছুন
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Stat({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-xl bg-paper px-3 py-2">
      <p className="text-sm text-muted">{label}</p>
      <p className="text-lg font-semibold tabular-nums text-ink">{value}</p>
      {hint ? <p className="text-xs tabular-nums text-muted">{hint}</p> : null}
    </div>
  );
}
