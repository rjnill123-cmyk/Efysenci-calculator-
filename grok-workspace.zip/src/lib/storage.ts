import { blankDraft, type Draft } from "@/lib/efficiency";

const DRAFT_KEY = "fl-draft-v1";
const SAVED_KEY = "fl-saved-v1";

export type SavedReport = {
  id: string;
  savedAt: number;
  draft: Draft;
};

function isStyle(value: unknown): value is Draft["styles"][number] {
  if (!value || typeof value !== "object") return false;
  const style = value as Record<string, unknown>;
  return (
    typeof style.id === "string" &&
    typeof style.name === "string" &&
    typeof style.qty === "string" &&
    typeof style.smv === "string"
  );
}

export function normalizeDraft(value: unknown): Draft | null {
  if (!value || typeof value !== "object") return null;
  const raw = value as Record<string, unknown>;
  const styles = Array.isArray(raw.styles) ? raw.styles.filter(isStyle) : [];
  const base = blankDraft(typeof raw.date === "string" ? raw.date : "");
  return {
    ...base,
    line: typeof raw.line === "string" ? raw.line : "",
    manpower: typeof raw.manpower === "string" ? raw.manpower : "",
    hours: typeof raw.hours === "string" ? raw.hours : "",
    otPeople: typeof raw.otPeople === "string" ? raw.otPeople : "",
    otHours: typeof raw.otHours === "string" ? raw.otHours : "",
    styles: styles.length > 0 ? styles : base.styles,
  };
}

export function loadDraft(): Draft | null {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    if (!raw) return null;
    return normalizeDraft(JSON.parse(raw));
  } catch {
    return null;
  }
}

export function saveDraft(draft: Draft): void {
  localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
}

export function loadSaved(): SavedReport[] {
  try {
    const raw = localStorage.getItem(SAVED_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.flatMap((item) => {
      if (!item || typeof item !== "object") return [];
      const row = item as Record<string, unknown>;
      const draft = normalizeDraft(row.draft);
      if (!draft || typeof row.id !== "string" || typeof row.savedAt !== "number") return [];
      return [{ id: row.id, savedAt: row.savedAt, draft }];
    });
  } catch {
    return [];
  }
}

export function saveSaved(rows: SavedReport[]): void {
  localStorage.setItem(SAVED_KEY, JSON.stringify(rows.slice(0, 30)));
}
