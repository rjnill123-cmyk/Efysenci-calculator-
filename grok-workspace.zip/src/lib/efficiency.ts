export type StyleInput = {
  id: string;
  name: string;
  qty: string;
  smv: string;
};

export type Draft = {
  date: string;
  line: string;
  manpower: string;
  hours: string;
  otPeople: string;
  otHours: string;
  styles: StyleInput[];
};

export type StyleCalc = {
  name: string;
  qty: number;
  smv: number;
  minutes: number;
};

export type Result = {
  styles: StyleCalc[];
  pieces: number;
  outputMinutes: number;
  regularMinutes: number;
  otMinutes: number;
  availableMinutes: number;
  manHours: number;
  efficiency: number;
};

export type Band = "good" | "mid" | "bad" | "idle";

export function num(value: string): number {
  const x = parseFloat(value);
  if (!Number.isFinite(x) || x < 0) return 0;
  return x;
}

/** Same rounding as the original sheet: no forced trailing zeros. */
export function fmt(x: number, d = 1): string {
  const v = Math.round(x * 10 ** d) / 10 ** d;
  return v.toString();
}

export function todayISO(): string {
  const d = new Date();
  const z = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
}

export function dateBn(iso: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return "";
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

export function newStyleId(): string {
  return `st-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

export function blankDraft(date = ""): Draft {
  return {
    date,
    line: "",
    manpower: "",
    hours: "",
    otPeople: "",
    otHours: "",
    styles: [{ id: "style-1", name: "", qty: "", smv: "" }],
  };
}

export function calculate(draft: Draft): Result {
  const styles = draft.styles.map((style, index) => {
    const qty = num(style.qty);
    const smv = num(style.smv);
    return {
      name: style.name.trim() || `স্টাইল ${index + 1}`,
      qty,
      smv,
      minutes: qty * smv,
    };
  });
  const manpower = num(draft.manpower);
  const hours = num(draft.hours);
  const otPeople = num(draft.otPeople);
  const otHours = num(draft.otHours);
  const regularMinutes = manpower * hours * 60;
  const otMinutes = otPeople * otHours * 60;
  const availableMinutes = regularMinutes + otMinutes;
  const outputMinutes = styles.reduce((sum, style) => sum + style.minutes, 0);
  const pieces = styles.reduce((sum, style) => sum + style.qty, 0);
  const efficiency = availableMinutes > 0 ? (outputMinutes / availableMinutes) * 100 : 0;
  return {
    styles,
    pieces,
    outputMinutes,
    regularMinutes,
    otMinutes,
    availableMinutes,
    manHours: availableMinutes / 60,
    efficiency,
  };
}

export function bandOf(result: Result): Band {
  if (result.availableMinutes <= 0) return "idle";
  if (result.efficiency >= 70) return "good";
  if (result.efficiency >= 50) return "mid";
  return "bad";
}

export function bandLabel(band: Band): string {
  if (band === "good") return "ভালো";
  if (band === "mid") return "মাঝারি";
  if (band === "bad") return "কম";
  return "";
}

export function buildReport(draft: Draft, result: Result): string {
  const manpower = num(draft.manpower);
  const hours = num(draft.hours);
  const otPeople = num(draft.otPeople);
  const otHours = num(draft.otHours);
  const date = dateBn(draft.date);
  const line = draft.line.trim();
  let report = "ফিনিশিং লাইন – দৈনিক ইফিসেন্সি রিপোর্ট\n";
  if (date) report += `তারিখ: ${date}\n`;
  if (line) report += `লাইন: ${line}\n`;
  report += "----------------\n";
  report += `ম্যান পাওয়ার: ${fmt(manpower, 2)} জন × ${fmt(hours, 2)} ঘণ্টা = ${fmt(result.regularMinutes / 60, 2)} ম্যান-আওয়ার\n`;
  if (otPeople > 0 && otHours > 0) {
    report += `অতিরিক্ত: ${fmt(otPeople, 2)} জন × ${fmt(otHours, 2)} ঘণ্টা = ${fmt(result.otMinutes / 60, 2)} ম্যান-আওয়ার\n`;
  }
  report += `মোট ম্যান-আওয়ার: ${fmt(result.manHours, 2)} (${fmt(result.availableMinutes, 0)} মিনিট)\n`;
  report += "----------------\nপ্রডাকশন:\n";
  result.styles.forEach((style, index) => {
    if (style.qty > 0 || style.smv > 0) {
      report += `${index + 1}) ${style.name}: ${fmt(style.qty, 0)} পিস × SMV ${fmt(style.smv, 2)} = ${fmt(style.minutes, 1)} মিনিট\n`;
    }
  });
  report += `মোট প্রডাকশন: ${fmt(result.pieces, 0)} পিস\nআউটপুট মিনিট: ${fmt(result.outputMinutes, 1)}\n`;
  report += "----------------\n";
  report += `টোটাল ইফিসেন্সি: ${fmt(result.efficiency, 2)}%\n`;
  report += "(সূত্র: আউটপুট মিনিট ÷ উপলব্ধ মিনিট × ১০০)";
  return report;
}
